package com.todo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.todo.dao.ToDoDAO;
import com.todo.model.StringDateSorter;
import com.todo.model.ToDo;

@Service
public class ToDoServiceImpl implements ToDoService{
	
	@Autowired
	ToDoDAO toDoDAO;

	@Override
	public void addToDo(ToDo toDo) {
		toDoDAO.save(toDo);		
	}

	@Override
	public void deleteToDo(int id) {
		toDoDAO.deleteById(id);
		
	}

	@Override
	public void updateToDo(ToDo toDo) {
		if(toDoDAO.existsById(toDo.getId())) {
			toDoDAO.save(toDo);
		}
		
	}

	@Override
	public List<ToDo> ListToDo() {
		return (List<ToDo>) toDoDAO.findAll();
	}

	@Override
	public ToDo getTodo(int id) {
		Optional<ToDo> optionalToDo=toDoDAO.findById(id);
		ToDo toDo= new ToDo();
		if(optionalToDo.isPresent()) {
			toDo=optionalToDo.get();
		}
		
		return toDo;
	}

	@Override
	public List<ToDo> listByUsername(String username) {
		
		List<ToDo> allTodo=toDoDAO.findByUsername(username);
		
		return allTodo;
	}
	

	@Override
	public List<ToDo> sortByDateToDo(String username) {
		List<ToDo> allTodosort=listByUsername(username);
		
		allTodosort.sort(new StringDateSorter());
		
		return allTodosort;
	}

	@Override
	public List<ToDo> listAllTodo() {
		return (List<ToDo>) toDoDAO.findAll();
	}
	
	
	

}
