package com.todo.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.todo.model.ToDo;

@Repository
public interface ToDoDAO extends CrudRepository<ToDo, Integer>{
		
	public List<ToDo> findByUsername(String username);
		
	//findByOrderBySeatNumberAsc();

}
