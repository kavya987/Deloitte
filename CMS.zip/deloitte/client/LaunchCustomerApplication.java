package com.cms.deloitte.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cms.deloitte.dao.CustomerDAO;
import com.cms.deloitte.dao.impl.CustomerDAOImpl;
import com.cms.deloitte.model.Customer;

public class LaunchCustomerApplication {
	
	public static void startCustomerApp() {
		
		CustomerDAO customerDAO= new CustomerDAOImpl();
		
		System.out.println("\n\nWelcome to Customer App");
		System.out.println("1.Add Customer");
		System.out.println("2.Update Customer");
		System.out.println("3.Delete Customer");
		System.out.println("4.List Customer");
		System.out.println("5.Find Customer");
		System.out.println("6.Exit");
		
		Scanner scanner= new Scanner(System.in);
		System.out.println("Enter your choice(1-6)");
		int choice=scanner.nextInt();
		
		if(choice==1) {
			//add
			Customer customer= new Customer();
			customer.acceptCustomerDetails();			
			
			if(customerDAO.isCustomerExists(customer.getCustomerId())) {
				System.out.println(customer.getCustomerName()+ " already exists.");
				
			}else {
				customerDAO.addCustomer(customer);
				System.out.println(customer.getCustomerName()+ ", added successfully .");
			}
			 
			
			//System.out.println(result);
			
		}else if(choice==2) {
			//update
			Customer customer= new Customer();
			customer.acceptCustomerDetails();
						
			if(customerDAO.isCustomerExists(customer.getCustomerId())) {
				customerDAO.updateCustomer(customer);
				System.out.println(customer.getCustomerName()+ ", updated successfully .");
				
			}else {
				customerDAO.addCustomer(customer);
				System.out.println(customer.getCustomerId()+ ", doesn't exist.");
			}
			
		}else if(choice==3) {
			//delete
			Scanner sc= new Scanner(System.in);			
			System.out.println("Enter id of customer to be deleted : ");
			int customerId=sc.nextInt();
			
			if(customerDAO.isCustomerExists(customerId)) {
				customerDAO.deleteCustomer(customerId);
				System.out.println(customerId+" deleted successfully .");
				
			}else {
				
				System.out.println(customerId+ " doesn't exist.");
			}
			
			
		}else if(choice==4) {
			//List
			List<Customer> allCustomers = new ArrayList<Customer>();
			
			
			allCustomers =customerDAO.listCustomer();
			System.out.println("List of all customers : ");
			System.out.println(allCustomers);
			
		}else if(choice==5) {
			//Find
			Scanner sc= new Scanner(System.in);			
			System.out.println("Enter id of customer : ");
			int customerId=sc.nextInt();
			
			Customer customer=customerDAO.findCustomer(customerId);	
			if(customer.getCustomerId()==customerId) {
				System.out.println("Customer found : ");
				System.out.println(customer);
			}else {
				System.out.println(customerId+ " doesn't exist.");
			}			
			
		}else if(choice==6) {
			//exit
			System.out.println("Thanks for using Customer App ");
			System.exit(0);
			
		}else
			System.out.println("invalid choice");	
	}
}
