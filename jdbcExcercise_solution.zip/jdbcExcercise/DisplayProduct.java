package jdbcExcercise;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DisplayProduct {
	
	public static void main(String[] args) throws SQLException {
		Connection connection= DBConnection.makeConnection();

		Statement statement=connection.createStatement();
		
		//4.Execute Query and read result
		ResultSet res= statement.executeQuery("select * from hr.product");
		
		while(res.next()) {
			System.out.print(res.getInt(1)+"\t");
			System.out.print(res.getString(2)+"\t");
			System.out.print(res.getString(3)+"\t");
			System.out.println(res.getInt(4)+"\t");			
		}
		
		//5.close connecton
		statement.close();
		connection.close();
	}

}
