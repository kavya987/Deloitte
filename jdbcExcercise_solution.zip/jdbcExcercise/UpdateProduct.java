package jdbcExcercise;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import jdbcDemo.DBConnection;

public class UpdateProduct {
	
	public static void main(String[] args) throws SQLException {
		
		Connection connection= DBConnection.makeConnection();
		
		Product product= new Product();
		product.accept();
		
		Statement statement1= connection.createStatement();
		ResultSet res= statement1.executeQuery("select * from hr.product where productid="+product.getProductId());
		
		if(res.next()) {
			
			PreparedStatement statement= connection.prepareStatement("update hr.product set productname=?,price=?,qoh=? where productid=?");
			
			statement.setInt(4, product.getProductId());
			statement.setString(1, product.getProductName());
			statement.setInt(2, product.getPrice());
			statement.setInt(3, product.getQoh());
			
			statement.executeUpdate();
			
			System.out.println(product.getProductName()+" updated successfully!!");
			
		}else {
			
			System.out.println("Record doesn't exist");
		}
		
	}

}
