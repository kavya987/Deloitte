package jdbcExcercise;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import jdbcDemo.DBConnection;

public class DeleteProduct {
	public static void main(String[] args) throws SQLException {
		
		Connection connection= DBConnection.makeConnection();
		
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter id of product to be deleted : ");
		int pId=sc.nextInt();
		

		Statement statement1= connection.createStatement();
		ResultSet res= statement1.executeQuery("select * from hr.product where productid="+pId);
		
		if(res.next())  {
			PreparedStatement statement= connection.prepareStatement("delete from hr.product where productid=?");
			
			statement.setInt(1, pId);
			
			statement.executeUpdate();
			
			System.out.println("Record deleted successfully!!");			
		}else {
			System.out.println("Record doesn't exist");
		}
		
		
	}

}
