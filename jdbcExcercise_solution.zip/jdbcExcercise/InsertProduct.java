package jdbcExcercise;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jdbcDemo.DBConnection;

public class InsertProduct {
	
	public static void main(String[] args) throws SQLException {
		
		Connection connection= DBConnection.makeConnection();
		
		Product product= new Product();
		product.accept();
		
		PreparedStatement statement= connection.prepareStatement("insert into hr.product values(?,?,?,?)");
		
		statement.setInt(1, product.getProductId());
		statement.setString(2, product.getProductName());
		statement.setInt(3, product.getPrice());
		statement.setInt(4, product.getQoh());
		
		statement.executeUpdate();
		
		System.out.println(product.getProductName()+" saved successfully!!");
	}

}
