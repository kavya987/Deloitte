package jdbcExcercise;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;



public class CreateProduct {
	
	public static void main(String[] args) throws SQLException {
		Connection connection= DBConnection.makeConnection();
		Statement statement= connection.createStatement();
		String query="create table hr.product(productId integer,productName varchar2(20),price integer,qoh integer)";
		statement.execute(query);
		System.out.println("Table created successfully");
		
		statement.close();
		connection.close();
	}

}
