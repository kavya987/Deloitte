package com.shopping.deloitte.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AuthenticateServlet
 */
public class AuthenticateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AuthenticateServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");

		PrintWriter out = response.getWriter();

//		RequestDispatcher dispatcher = request.getRequestDispatcher("WelcomeServlet");
//		dispatcher.forward(request, response);

		boolean alreadyVisited = false;
		
		Cookie allCookies[]=request.getCookies();

		if (allCookies != null) {
			for (Cookie c : allCookies) {
				if (c.getName().equals(username)) {
					alreadyVisited = true;
					break;
				}
			}
		}

		out.println("<h1>Successfully Authenticated");

		if (!alreadyVisited) {
			out.println("<h2>Welcome, you are visiting for the first time : " + username);
			Cookie cookie=new Cookie(username, username);
			response.addCookie(cookie);
			System.out.println("cookie set");
		} else {
			out.println("<h2>Welcome anyway, you have already visited : " + username);
			System.out.println("already visited");
		}
		
		out.println("<h1><form action='WelcomeServlet'>");
		out.println("<h1>Wife Name : <input type='text' name='wifeName'>");
		out.println("<h1><input type='hidden' name='username' value="+username+">");
		out.println("<h1><input type='submit' value='enter'>");
		out.println("<h1></form>");

		/*
		 * } else { out.println("Invalid Username or password");
		 * out.println("<a href=index.html>Home</a>");
		 * response.sendRedirect("loginForm.html"); }
		 */

		/*
		 * if(username.equalsIgnoreCase("admin")){ RequestDispatcher
		 * dispatcher=request.getRequestDispatcher("AdminServlet");
		 * dispatcher.forward(request, response); }else
		 * if(username.equalsIgnoreCase("guest")){ RequestDispatcher
		 * dispatcher=request.getRequestDispatcher("GuestServlet");
		 * dispatcher.forward(request, response); }else { RequestDispatcher
		 * dispatcher=request.getRequestDispatcher("OthersServlet");
		 * dispatcher.forward(request, response); }
		 */

	}

}
