package com.product.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;

import com.product.dao.ProductDAO;
import com.product.dao.impl.ProductDAOImpl;
import com.product.model.Product;

/**
 * Servlet implementation class ProductController
 */
public class ProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductController() {
        super();
       
    }
    
    @Override
    public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
    	
    	response.setContentType("text/html");
    	PrintWriter out= response.getWriter();
    	
    	
    	
    	int productId=Integer.parseInt(request.getParameter("productId"));
		String productName=request.getParameter("productName");
		int qoh =Integer.parseInt(request.getParameter("qoh"));
		int billAmount=Integer.parseInt(request.getParameter("BillAmount"));
		
		Product product= new Product(productId, productName, qoh, billAmount);
		
		response.getWriter().println("<h2>Customer Id :"+ productId +"</h2>");
		
		ProductDAO productDAO= new ProductDAOImpl();
		if(productDAO.isProductExists(productId)) {
			out.println("<h2> "+productName +" already Exists</h2>");
		}else {
			productDAO.saveProduct(product);
			out.println("<h2> "+productName +" saved Successfully!! </h2>");
			
		}
		
		
		
		out.println("<form action=displayProduct.jsp>");
		out.println("<input type=\"submit\" value=\"View products\" />");
		out.println("</form");
    	
    	
		
    	
    }



}
