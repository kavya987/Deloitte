package com.product.model;

public class Product {
	private int productId;
	private String productName;
	private int qoh;
	private int billAmount;
	
	public Product() {
	}

	public Product(int productId, String productName, int qoh, int billAmount) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.qoh = qoh;
		this.billAmount = billAmount;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getQoh() {
		return qoh;
	}

	public void setQoh(int qoh) {
		this.qoh = qoh;
	}

	public int getBillAmount() {
		return billAmount;
	}

	public void setBillAmount(int billAmount) {
		this.billAmount = billAmount;
	}

	@Override
	public String toString() {
		return "\nProduct [productId=" + productId + ", productName=" + productName + ", qoh=" + qoh + ", billAmount="
				+ billAmount + "]";
	}
	
}
