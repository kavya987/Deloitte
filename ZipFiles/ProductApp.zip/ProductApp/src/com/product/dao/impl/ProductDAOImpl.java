package com.product.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.product.dao.ProductDAO;
import com.product.model.Product;

public class ProductDAOImpl implements ProductDAO{
	
	Configuration configuration= null; 
	
	SessionFactory factory=null;
	
	public ProductDAOImpl() {
		configuration= new Configuration().configure(); 
		factory=configuration.buildSessionFactory();
	}

	@Override
	public boolean saveProduct(Product product) {
		
		Session session= factory.openSession();  //connected to database
		
		Transaction transaction=session.beginTransaction();
		session.save(product); //add product
		
		transaction.commit();		
		session.close();
		
		
		return false;
	}

	@Override
	public List<Product> listProducts() {
		
		Session session= factory.openSession();  //connected to database
		Query query=session.createQuery("from Product");		
		
		List<Product> allProducts =query.list();
		session.close();
		return allProducts;		
	}

	@Override
	public boolean isProductExists(int productId) {
		
		Session session= factory.openSession();  //connected to database
		Product product= (Product) session.get(Product.class, productId);	
		session.close();
		
		if(product==null)
			return false;
		else
			return true;
	}

}
