package com.product.dao;

import java.util.List;

import com.product.model.Product;

public interface ProductDAO {
	public boolean saveProduct(Product product);
	public List<Product> listProducts();
	public boolean isProductExists(int productId);
}
