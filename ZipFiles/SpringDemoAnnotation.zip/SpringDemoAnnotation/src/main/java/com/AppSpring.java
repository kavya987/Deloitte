package com;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.config.AppConfig;

/**
 * Hello world!
 *
 */
public class AppSpring 
{
    public static void main( String[] args )
    {
    	
    	//Resource resource= new ClassPathResource("beans.xml");
    	AbstractApplicationContext context= new AnnotationConfigApplicationContext(AppConfig.class);
    	
    	Customer customer=context.getBean(Customer.class);
    	
    	customer.setCustomerId(3435);
    	customer.setCustomerName("Kavya");
    	customer.setCustomerAddress("Pune");
    	customer.setBillAmount(90538);
    	
    	ContactDetails contactDetails=context.getBean(ContactDetails.class);
    	contactDetails.setMobileNumber(896732);
    	contactDetails.setEmailId("bchkjashd@kc");
    	
    	
    	System.out.println(customer);
    	
    	Customer customer2=context.getBean(Customer.class);
    	
    	context.registerShutdownHook();
    }
}
