package com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.config.AppConfig;

public class AppSpring 
{
    public static void main( String[] args )
    {
    	
    	//Resource resource= new ClassPathResource("beans.xml");
    	ApplicationContext context= new AnnotationConfigApplicationContext(AppConfig.class);
    	
    	Email email=context.getBean(Email.class);
    	
    	To to = context.getBean(To.class);
    	to.setToName("Kavya");
    	to.setToEmail("kjzkl@gsh.com");
    	
    	From from = context.getBean(From.class);
    	from.setFromName("Merin");
    	from.setFromEmail("bfshabh@hdiz.com");
    	
    	
    	System.out.println(email);
    }
}
