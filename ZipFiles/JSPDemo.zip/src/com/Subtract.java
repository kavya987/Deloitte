package com;

public class Subtract {
	
	public int subtractNumbers(int i,int j){
		return i-j;
		}

}
