package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Welcome
 */
public class Welcome extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
    public Welcome() {
        System.out.println("cons called");
        // TODO Auto-generated constructor stub
    }
    
    int counter=0;
    
    public void display() {
    	System.out.println("display");
    }
    
    public void init() {
    	System.out.println("INIT");
    }

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Get");
		
		counter++;
		
		String uname=request.getParameter("username");
		String pass=request.getParameter("password");

		response.getWriter().println("<body bgcolor=red><h1>Welcome to my website, "+uname+"</h1>");
		response.getWriter().println("<h1>You are visitor number: "+counter);
		response.getWriter().println("<h2><a href='shop.html'>Shop</a>");
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Post");
		
		counter++;
		
		String uname=request.getParameter("username");
		String pass=request.getParameter("password");

		response.getWriter().println("<body bgcolor=orange><h1>Welcome to my website, "+uname+"</h1>");
		response.getWriter().println("<h1>You are visitor number: "+counter);
		response.getWriter().println("<h2><a href='shop.html'>Shop</a>");
	}
    
    
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("Service");
		
		counter++;
		
		String uname=request.getParameter("username");
		String pass=request.getParameter("password");

		response.getWriter().println("<body bgcolor=cyan><h1>Welcome to my website, "+uname+"</h1>");
		response.getWriter().println("<h1>You are visitor number: "+counter);
		response.getWriter().println("<h2><a href='shop.html'>Shop</a>");

	}
	
	@Override
	public void destroy() {
		System.out.println("Destroy");
	}

}
