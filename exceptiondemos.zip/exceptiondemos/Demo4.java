package exceptiondemos;


import java.util.Scanner;

class InvalidAgeException extends Exception{
	
	public InvalidAgeException() {
		// TODO Auto-generated constructor stub
	}
	public InvalidAgeException(String msg) {
		super(msg);
	}
}

class NewYearParty{
	
	int eligibleAge=16;
	Scanner sc= new Scanner(System.in);
	int age;
	public void enterClub() throws InvalidAgeException{
		
		System.out.println("Enter your age: ");
		age=sc.nextInt();
		if(age<eligibleAge) {
			throw new InvalidAgeException("Under Age");
		}else
			System.out.println("Welcome");
	
	System.out.println("Entered");
	}
	
	
}

public class Demo4 {
	
	
	public static void main(String[] args) {
		System.out.println("main started");
		
		NewYearParty party= new NewYearParty();
		try {
			party.enterClub();
		} catch (InvalidAgeException e) {
			System.out.println("under age");
			//e.printStackTrace();
		}
		
		System.out.println("main ends");
		
	}

}
