package exceptiondemos;

public class Demo2 {
	
	public void display1() throws InterruptedException {
		System.out.println("Welcome to display");
		Thread.sleep(1000);
		System.out.println("bye");
	}
	public void display2() throws InterruptedException {
		System.out.println("Welcome to display");
		Thread.sleep(1000);
		System.out.println("bye");
	}
	
	public static void main(String[] args) throws InterruptedException {
		System.out.println("Main started");
		Demo2 d= new Demo2();
		d.display1();
		d.display2();
		System.out.println("main bye");
		
	}

}
