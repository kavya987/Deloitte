package exceptiondemos;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Demo3 {
	
	int num1,num2,result;
	Scanner sc= new Scanner(System.in);
	
	public void diaplay() throws RuntimeException{
		
		System.out.println("Welcome to display");
	
		
		
			System.out.println("Enter 1st number : ");
			num1=sc.nextInt();
			System.out.println("Enter 2nd number : ");
			num2=sc.nextInt();
			result=num1/num2;
			System.out.println(result);
		System.out.println("bye");
	}
	
	
	public static void main(String[] args) throws RuntimeException {
		System.out.println("main started");
		
		Demo3 d= new Demo3();
		d.diaplay();
		
		System.out.println("main ends");
		
	}

}
