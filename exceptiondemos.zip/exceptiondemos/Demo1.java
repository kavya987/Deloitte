package exceptiondemos;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Demo1 {
	
	int num1,num2,result;
	Scanner sc= new Scanner(System.in);
	
	public void diaplay() {
		
		System.out.println("Welcome to display");
		try {
			System.out.println("Enter 1st number : ");
			num1=sc.nextInt();
			System.out.println("Enter 2nd number : ");
			num2=sc.nextInt();
			result=num1/num2;
			System.out.println(result);
			
		} catch (InputMismatchException e) {
			System.out.println("input mismatch");
		}catch (ArithmeticException e) {
			System.out.println("divide by 0");
		}
	}
	
	
	public static void main(String[] args) {
		System.out.println("main started");
		
		Demo1 d= new Demo1();
		d.diaplay();
		
		System.out.println("main ends");
		
	}

}
