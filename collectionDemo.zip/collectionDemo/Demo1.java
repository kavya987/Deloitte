package collectionDemo;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

public class Demo1 {
	public static void main(String[] args) {
		Set<String> names= new LinkedHashSet<>();
		
		names.add("hjadsc");
		names.add("fgdf");
		names.add("Neha");
		names.add("gdfg");
		names.add("qewdf");
		
		System.out.println(names);
		
		
		Iterator<String> i = names.iterator();
		
		while(i.hasNext()) {
			String str=i.next();
			if(str.equals("Neha"))
				continue;
			System.out.println(str);
			
		}
		
		System.out.println(names);
		
		

		
		
		
	}

}
