package collectionDemo;

import java.util.Map;
import java.util.TreeMap;

public class MapDemo {
	
	public static void main(String[] args) {
		Map<Integer, String> allData= new TreeMap<Integer, String>();
		
		allData.put(1093, "kalpana");
		allData.put(68943, "jbd");
		allData.put(12, "Neha");
		
		System.out.println(allData);
		
	}

}
