package collectionDemo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class HashMapDemo {
	
	public static void main(String[] args) {
		HashMap<String, Double> hm= new HashMap<>();
		
		hm.put("John Doe", 112.08);
		hm.put("Tom Smith", 408.9);
		hm.put("harry", 678253.8);
		hm.put("Ralph Smith", 112.08);
		
		Set set= hm.entrySet();
		
		Iterator i =set.iterator();
		
		while(i.hasNext()) {
			
			Map.Entry mee =(Map.Entry)i.next();
			System.out.print(mee.getKey()+": ");
			System.out.println(mee.getValue());
		}
		
		System.out.println();
		
		double balance=((Double) hm.get("John Doe")).doubleValue();
		hm.put("John Doe", new Double(balance+1000));
		System.out.println(hm);
		
	}

}
