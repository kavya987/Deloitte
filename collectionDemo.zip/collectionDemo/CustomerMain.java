package collectionDemo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class CustomerMain {
	
	public static void main(String[] args) {
		
		List<Customer> allCustomer = new ArrayList<Customer>();
		
		Customer customer1 = new Customer(101, "Jaya", "Pune", 89364);
		
		allCustomer.add(customer1);
		allCustomer.add(new Customer(102, "Pooja", "Delhi", 89058));
		allCustomer.add(new Customer(103, "Tarun", "Pune", 83958));
		allCustomer.add(new Customer(104, "Harish", "Mumbai", 89580));
		allCustomer.add(new Customer(105, "Ahmed", "Bangalore", 89568));
		allCustomer.add(new Customer(106, "Kavya", "Kochi", 958));
		
		System.out.println("before sorting");
		System.out.println(allCustomer);
		
		Scanner sc = new Scanner(System.in); 
		
		System.out.println("Sort on 1.Name 2.Address 3.BillAmount ?");
		int choice=sc.nextInt();
		
		if(choice==3) {
			Collections.sort(allCustomer);
			System.out.println("After sorting on Bill Amount");
			System.out.println(allCustomer);
		}else if(choice==1) {
			Collections.sort(allCustomer,new NameComparator());
			System.out.println("After sorting on Name");
			System.out.println(allCustomer);
		}else if(choice==2) {
			Collections.sort(allCustomer, new Comparator<Customer>() {

				@Override
				public int compare(Customer o1, Customer o2) {
					if(o1.getCustomerAddress().compareTo(o2.getCustomerAddress())>0)
						return 0;
					else 
						return -1;
				}
			});
			System.out.println("After sorting on Address");
			System.out.println(allCustomer);
		}
		
		

	}

}
