package collectionDemo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class Demo2 {
	public static void main(String[] args) {
		List<String> names= new ArrayList<>();
		
		names.add("hjadsc");
		names.add("fgdf");
		names.add("gdfg");
		names.add("qewdf");
		
		System.out.println(names);
		names.add("zvxgs");
		System.out.println(names);
		
		Collections.sort(names);
		System.out.println(names);
		
		
		
	}

}
