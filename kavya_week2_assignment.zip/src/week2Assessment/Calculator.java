package week2Assessment;

import java.util.Scanner;

public class Calculator {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		
		System.out.println("1.Add");
		System.out.println("2.Subtract");
		System.out.println("3.Multiply");
		System.out.println("4.Divide");

		System.out.println("Enter your choice");
		int choice=sc.nextInt();
		
		
		System.out.println("Enter 1st number: ");
		int num1=sc.nextInt();
		System.out.println("Enter 2nd number: ");
		int num2=sc.nextInt();
		
		Arithmetic[] array= {new Add(), new Subtract(), new Multiply(), new Divide()};
		
		array[choice-1].calculate(num1,num2);

	}

}
