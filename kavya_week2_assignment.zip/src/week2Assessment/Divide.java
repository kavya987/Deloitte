package week2Assessment;

public class Divide extends Arithmetic{
	
	public Divide() {
	}
	
	

	@Override
	public void calculate(int num1,int num2) {
		if(num2!=0) {
			System.out.println(num1+"/"+num2+" = "+((double)num1/(double)num2));		
		}else
			System.out.println("Can't divide by zero");
		
	}

}
