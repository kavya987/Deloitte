package week2Assessment;

public class Subtract extends Arithmetic {
	
	public Subtract() {
	}
	
	

	@Override
	public void calculate(int num1,int num2) {
		System.out.println(num1+"-"+num2+" = "+(num1-num2));		
	}

}
