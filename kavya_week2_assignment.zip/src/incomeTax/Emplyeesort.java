package incomeTax;

import java.util.Comparator;

public class Emplyeesort implements Comparator<EmplyeeVo> {

	@Override
	public int compare(EmplyeeVo e1, EmplyeeVo e2) {
		if(e1.getIncometax()>e2.getIncometax())
			return 1;
		else if(e1.getIncometax()==e2.getIncometax())
			return 0;
		else
			return -1;
	}
	
	
}
