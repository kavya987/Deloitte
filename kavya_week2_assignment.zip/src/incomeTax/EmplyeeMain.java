package incomeTax;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;



public class EmplyeeMain {
	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		System.out.println("Enter no of Employees : ");
		int n=in.nextInt();
		
		
		EmplyeeBo emplyeeBo= new EmplyeeBo();
		EmplyeeVo[] employees= new EmplyeeVo[n];
		
		for (int i = 0; i < n; i++) {
			System.out.println("Enter Employee details ");
			System.out.println("Enter Employee ID");
			int empid=in.nextInt();
			System.out.println("Enter Employee Name");
			String empname=in.next();
			System.out.println("Enter Annual Income");
			double annualincome=in.nextDouble();
			employees[i]=new EmplyeeVo(empid, empname, annualincome, 0);		
		}
		
		for(EmplyeeVo e:employees) {
			emplyeeBo.calIncomeTax(e);
		}
		
		List<EmplyeeVo> allEmployees= Arrays.asList(employees);
		
		System.out.println("All Employees : ");
		System.out.println(allEmployees);
		
		Collections.sort(allEmployees,new Emplyeesort());
		
		System.out.println("Sorted Employee List");
		System.out.println(allEmployees);
		
	}

}
