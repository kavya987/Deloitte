package incomeTax;

public class EmplyeeBo {
	
	public void calIncomeTax(EmplyeeVo emplyeeVo) {
		double a=emplyeeVo.getAnnualincome();
		if(a<250000) {
			emplyeeVo.setIncometax(0);;
		}
		else if(a<500000)
		{
			emplyeeVo.setIncometax(0.1*a);
		}
		else
		{
			emplyeeVo.setIncometax(0.2*a);
		}

	} 

}
