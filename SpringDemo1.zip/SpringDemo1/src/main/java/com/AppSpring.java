package com;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class AppSpring 
{
    public static void main( String[] args )
    {
    	
    	/*Resource resource= new ClassPathResource("beans.xml");
    	BeanFactory factory= new XmlBeanFactory(resource);*/
    	
    	AbstractApplicationContext context= new ClassPathXmlApplicationContext("beans.xml");
    	
    	Customer customer= (Customer) context.getBean("cust3");
    	
    	
    	//customer.setCustomerName("Kavya");
    	System.out.println(customer);
    	
    	context.registerShutdownHook();
    }
}
