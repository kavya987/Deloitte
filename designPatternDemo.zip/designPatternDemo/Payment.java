package designPatternDemo;

//singleton class
public class Payment {
	private static Payment payment= new Payment();
	
	public Payment() {
		System.out.println("payment memory alocated");
	}
	public static Payment getPaymentObject() {
		return payment;
	}
	
	public void pay(int amount) {
		System.out.println("Payment done for INR: "+amount);
		
	}

}
