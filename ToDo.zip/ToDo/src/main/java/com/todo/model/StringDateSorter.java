package com.todo.model;

import java.util.Comparator;

public class StringDateSorter implements Comparator<ToDo>{

	@Override
	public int compare(ToDo o1, ToDo o2) {
		return o2.getTargetDate().compareToIgnoreCase(o1.getTargetDate());
	}

}
