package com.todo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.todo.dao.LoginDAO;
import com.todo.model.Login;

@Service
public class LoginServiceImpl implements LoginService {

	@Autowired
	LoginDAO loginDao;

	@Override
	public void addUser(Login login) {

		loginDao.save(login);
	}

	@Override
	public boolean validateuser(Login login) {
		
		boolean result=false;
		Login loginCheck= loginDao.findByUsernameAndPassword(login.getUsername(), login.getPassword());
		if(loginCheck!=null)
			result=true;
		return result;
	}

}
