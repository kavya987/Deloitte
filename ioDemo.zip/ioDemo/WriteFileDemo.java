package ioDemo;

import java.io.FileWriter;
import java.io.IOException;

public class WriteFileDemo {
	
	public static void main(String[] args) throws IOException {
		
		FileWriter fw= new FileWriter("record.txt");
		
		fw.write("My name is kavya M");
		fw.close();
		
		System.out.println("Done");
		
		
	}
}
