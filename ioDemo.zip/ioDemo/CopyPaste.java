package ioDemo;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class CopyPaste {

	public static void main(String[] args) throws IOException {

		while (true) {

			Scanner sc = new Scanner(System.in);

			System.out.println("Enter the file to copy :");
			String filecopy = sc.next();

			File fcopy = new File(filecopy);
			if (fcopy.exists()) {
				FileReader reader = new FileReader(fcopy);

				System.out.println("Enter the file to paste :");
				String filepaste = sc.next();

				File fpaste = new File(filepaste);
				FileWriter fw = new FileWriter(fpaste);

				int i = 0;
				while ((i = reader.read()) != -1) {
					fw.write((char) i);
				}
				reader.close();
				fw.close();
				System.out.println("Success! Copied '" + filecopy + "' to '" + filepaste + "'");
				break;
			} else {
				System.out.println("'" + filecopy + "' does not exist.");
			}
		}
	}
}
