package ioDemo;

import java.io.IOException;
import java.io.RandomAccessFile;

public class RandomDemo {
	
	public static void main(String[] args) throws IOException {
		RandomAccessFile file= new RandomAccessFile("friday.txt", "rw");
		file.writeUTF("today is friday");
		System.out.println(file.getFilePointer());
		file.seek(0);
		String str= file.readUTF();
		System.out.println("File content is : ");
		System.out.println(str);
		
		file.seek(file.length());
		file.writeUTF("Kavya");
		file.seek(file.length()-5);
		str= file.readLine();
		
		file.close();
		
		System.out.println("File content is : ");
		System.out.println(str);
	}

}
