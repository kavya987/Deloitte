package ioDemo;

import java.io.File;
import java.io.IOException;

public class Demo2 {
	
	public static void main(String[] args) throws IOException {
		File file= new File("C:\\deloitte\\newyear");
		
		if(file.exists()) {
			System.out.println("file exists");
		}else {
			file.createNewFile();
			System.out.println("file created");
		}
		System.out.println("Done");
	}

}
