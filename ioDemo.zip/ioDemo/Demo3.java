package ioDemo;

import java.io.File;
import java.io.IOException;

public class Demo3 {
	
	public static void main(String[] args) throws IOException {
		
		String fs= File.separator;
		System.out.println(fs);
		
		File file= new File("C:"+fs+"deloitte"+fs+"K"+fs+"T"+fs+"happynewyear.txt");
		File h=new File("C:"+fs+"deloitte"+fs+"K"+fs+"T");
		
		if(file.exists()) {
			System.out.println("file exists");
		}else {
			h.mkdirs();
			file.createNewFile();
			System.out.println("File Created");
			}
	}

}
