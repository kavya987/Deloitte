package ioDemo;

import java.io.File;
import java.io.IOException;

public class Demo1 {
	
	public static void main(String[] args) throws IOException {
		File file= new File("C:\\deloitte\\K\\T\\newyear.txt");
		File h=new File("C:\\deloitte\\K\\T");
		
		if(file.exists()) {
			System.out.println("file exists");
		}else {
			h.mkdirs();
			file.createNewFile();
			System.out.println("File Created");
			}
	}

}
