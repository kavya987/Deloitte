package ioDemo;

import java.io.File;
import java.io.IOException;

public class batch {
	
	public static void main(String[] args) throws IOException {
		File file= new File("c:\\deloitte\\Batch\\BatchMates.txt");
		File folder= new File("c:\\deloitte\\Batch");
		if(file.exists()) {
			System.out.println("file exists");
			File[] file1=folder.listFiles();
			System.out.println("List of files and Folders : ");
			for(File f :file1) {
				if(f.isFile())
					System.out.println(f.getName()+" is a file");
				else
					System.out.println(f.getName()+" is a directory");				
			}	
		}else {
			folder.mkdirs();
			file.createNewFile();
			System.out.println("File Created");
			}
	}
}
