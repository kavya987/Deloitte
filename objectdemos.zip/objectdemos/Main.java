package objectdemos;

public class Main {
	
	
	public static void main(String[] args) {
		Customer customer= new Customer(9555, "gda", "bjdskja", 233132);
		
		System.out.println(customer);
		customer.setBillAmount(12000);
		System.out.println(customer);
	}

}
