package objectdemos;

public class MainProducts {
	
	public static void main(String[] args) {
		Product p1= new Product(1000, "Brush", 10, 12);
		Product p2= new Product(1001, "Paste", 4, 20);
		
		System.out.println(p1);
		System.out.println(p2);
	}

}
